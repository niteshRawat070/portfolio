import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Vite configuration
export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000, // This ensures the dev server runs on port 3000
    open: true,  // This will open the browser automatically
  },
})
